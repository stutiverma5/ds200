import pandas as pd
import matplotlib.pyplot as plt
import sys

read=pd.read_csv("data1.csv", header=None, names=['col1', 'col2'])
plotMap=[]


plotMap.append(read['col1'].dropna().tolist())


plt.boxplot(plotMap)


plt.xticks([1],["title"])

plt.xlabel("Year")
plt.ylabel("Urban Population percentage")
plt.title("Proportion of urban population and total population")



plt.legend()
plt.show()
