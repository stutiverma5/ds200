import pandas as pd
import matplotlib.pyplot as plt
import sys

#input to this is data1.csv,data2.csv

read=pd.read_csv("data.csv", header=None, names=['col1','col2'])

plt.scatter(read['col1'],read['col2'],color='red',label="Urban")

plt.xlabel("Year")
plt.ylabel("Urban Population percentage")
plt.title("Proportion of urban population and total population")

plt.legend()
plt.show()
