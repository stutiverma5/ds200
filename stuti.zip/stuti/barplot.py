import pandas as pd
import matplotlib.pyplot as plt
import sys



read=pd.read_csv("data.csv", header=None, names=['col1', 'col2'])


plt.bar(read['col1'],read['col2'],color='#ddbbaa',label="population")


plt.xlabel("Year")
plt.ylabel("Urban Population percentage")
plt.title("Proportion of urban population and total population")


plt.legend()
plt.show()