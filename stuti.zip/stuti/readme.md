 
Data was extracted from following link to generate barplot, scatterplot, and boxplot.
https://data.gov.in/catalog/proportion-urban-population-and-total-population

From Barplot and scatterplot, we deduce that, urban population is linearly increasing with every decade.
We created data1.csv file for boxplot and data.csv for scatterplot and barplot, from extracted data.
From Boxplot, we deduce that urban population increased with a mush rapid rate in last twenty year than in the first thirty year.

